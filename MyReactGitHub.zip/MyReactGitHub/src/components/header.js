import React from "react";
import { Link } from "react-router-dom";

export const Header = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            React App
          </Link>
        </div>
        <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav">
            <li className="active">
              <Link to="/">
                Home
                <span className="sr-only" />
              </Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/form">Form</Link>
            </li>
            <li>
              <Link to="/formdemo2">Form Demo 2</Link>
            </li>
            <li>
              <Link to="/formeg">FormEg</Link>
            </li>
            <li>
              <Link to="/refsdemo">Refs Demo</Link>
            </li>
            <li>
              <Link to="/customerinfo">Customer info</Link>
            </li>
            <li>
              <Link to="/homes">Homes</Link>
            </li>
            <li>
              <Link to="/lifecycle">Life Cycle</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/proptypes">Prop Types</Link>
            </li>
            <li>
              <Link to="/parent">Parent</Link>
            </li>
            <li>
              <Link to="/parent1">Parent 1</Link>
            </li>
          </ul>
          <ul className="nav navbar-nav navbar-right">
            {/* <li><Link to="/login">Login</Link></li> */}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;

import React from 'react'

const FunClassDemo = () => {
    return <h1>This is my function</h1>
}
export default FunClassDemo;
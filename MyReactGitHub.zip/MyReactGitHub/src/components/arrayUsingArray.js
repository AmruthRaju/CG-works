import React, { Component } from 'react'

export class NumListClassComp extends React.Component {
    render() {
        console.log(this.props);
        return (
            <div>
                 <ul>
                    <li>1</li>
                    <li>2</li>
                    <li>3</li>
                    <li>4</li>
                    {this.props.numbers.map((n) =>
                        <li>key={n}</li>)}
                </ul> 
                {/* <div>
                    <p>Name: {this.props.name}</p>
                </div> */}
                {/* <div>
                    <h3>Hobbies :</h3>
                    <ul>
                        {this.props.user.hobbies.map((hobby) => <li>{hobby}</li>)}
                    </ul>
                </div>  */}
            </div>
        )
    }
}




export default NumListClassComp;

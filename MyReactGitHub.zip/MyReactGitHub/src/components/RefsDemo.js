import React from "react";

class RefsDemo extends React.Component {
  constructor(props) {
    super(props);
    this.myrefvar = React.createRef();
  }
  componentDidMount() {
    this.myrefvar.current.focus();
    console.log(this.myrefvar);
  }

  render() {
    return (
      <div>
        <input type="text" ref={this.myrefvar} />
        <button>Button</button>
      </div>
    );
  }
}
export default RefsDemo;

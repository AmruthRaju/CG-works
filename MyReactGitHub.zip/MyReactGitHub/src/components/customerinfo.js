import React from "react";
import CutsomerDisplay from "./CustomerDisplay";

class Customerinfo extends React.Component {
  constructor() {
    super();
    // step 1
    this.state = {
      user: {
        userName: "",
        userEmail: "",
        userMobile: "",
        userAddress: "",
        userDescription: "",
        userDateofVisit: ""
      }, // user end
      display: false
    }; // state end
  } // constructor end

  // step 4 define an method method
  handleSubmit(e) {
    e.preventDefault();
    alert(`
      User Name: ${this.state.user.userName}
      Email: ${this.state.user.userEmail}
      Mobile: ${this.state.user.userMobile}
      Address: ${this.state.user.userAddress}
      Description: ${this.state.user.userDescription}
      Date of Visit: ${this.state.user.userDateofVisit}`);
    this.setState({ display: true });
    console.log();
  }

  UpdateState(ctrl, value) {
    const { user } = this.state; // get the current state
    user[ctrl] = value; // update the user entered data
    this.setState({ user }); // update the new
  }

  resetState() {
    this.setState({
      user: {
        userName: "",
        userEmail: "",
        userMobile: "",
        userAddress: "",
        userDescription: "",
        userDateofVisit: ""
      }, // user end
      display: false // user end
    }); // state end
  }

  render() {
    const { user } = this.state;
    return (
      <div>
        <h1>State Add and Delete</h1>
        <form onSubmit={e => this.handleSubmit(e)}>
          <label>User Name:</label>&nbsp;
          <input
            type="text"
            value={user.userName}
            onChange={e => this.UpdateState("userName", e.currentTarget.value)}
          />
          <br />
          <label>Email:</label>&nbsp;
          <input
            type="text"
            value={user.userEmail}
            onChange={e => this.UpdateState("userEmail", e.currentTarget.value)}
          />
          <br />
          <label>Mobile:</label>&nbsp;
          <input
            type="text"
            value={user.userMobile}
            onChange={e => this.UpdateState("userMobile", e.currentTarget.value)}
          />
          <br />
          <label>Address:</label>&nbsp;
          <input
            type="text"
            value={user.userAddress}
            onChange={e => this.UpdateState("userAddress", e.currentTarget.value)}
          />
          <br />
          <label>Description:</label>&nbsp;
          <input
            type="text"
            value={user.userDescription}
            onChange={e => this.UpdateState("userDescription", e.currentTarget.value)}
          />
          <br />
          <label>Date of visit:</label>&nbsp;
          <input
            type="text"
            value={user.userDateofVisit}
            onChange={e => this.UpdateState("userDateofVisit", e.currentTarget.value)}
          />
          <br />
          <button type="submit">Button</button>
        </form>
        {this.state.display ? (
          <CutsomerDisplay deleteCustomer={e => this.resetState()} userData={this.state.user} />
        ) : null}
        {/* <CutsomerDisplay userData={this.state.user} deleteCustomer={e => this.resetState()} /> */}
      </div>
    );
  }
}

export default Customerinfo;

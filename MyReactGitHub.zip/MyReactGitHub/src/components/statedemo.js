import React from 'react'

class StateDemo extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            message: this.props.message,
            clicks: 0,
            show: true
        }

    }
    changeMessage() {
        this.setState({
            message: 'Thank you for you visit.'
        })
    }
    IncrementItem = () => {
        this.setState({ clicks: this.state.clicks + 1 });
      }
      DecreaseItem = () => {
        this.setState({ clicks: this.state.clicks - 1 });
      }
    render() {
        return (
            <div>
                <h1>{this.state.message} </h1>
                <button className="btn btn-primary" onClick={() => this.changeMessage()}>Update State</button><br/><br />
                Count:{this.state.clicks}<br/>
                <button className="btn btn-success" onClick={this.IncrementItem}>Increment</button>&nbsp;
                <button className="btn btn-danger" onClick={this.DecreaseItem}>Decrement</button>
            </div>
        )
    }
}

export default StateDemo;
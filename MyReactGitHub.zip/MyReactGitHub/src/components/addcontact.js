import React from "react";

class AddContact extends React.Component {
  contactname = React.createRef();
  contactnumber = React.createRef();

  handleAddContact = event => {
    let contObject = {
      contactname: this.contactname.current.value,
      contactnumber: this.contactnumber.current.value
    };
    this.props.addContacts(contObject);
    event.preventDefault();
  };
  render() {
    return (
      <div className="well">
        <h1>Add Contact</h1>
        <form>
          Contact Name :&nbsp;
          <input ref={this.contactname} />
          <br />
          <br />
          Contact Number :&nbsp;
          <input ref={this.contactnumber} />
          <br />
          <br />
          <button onClick={this.handleAddContact} className="btn btn-success">
            Add Contact
          </button>
        </form>
      </div>
    );
  }
}

export default AddContact;

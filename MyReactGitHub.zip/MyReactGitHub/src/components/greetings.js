import React, { Component } from 'react'

class Greetings extends Component {
    render() {
        return (
            <div>
                <h1>Hello Andy</h1>
                
            </div>
        )
    }
}
export default Greetings;
import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Welcome from "./components/welcome";
import FunClassDemo from "./components/functioncomponent";
import Home from "./components/home";
import Greeting from "./components/greeting";
import Greetings from "./components/greetings";
import NumListClassComp from "./components/arrayUsingArray";
import EventDemo1 from "./components/eventDemo1";
import UserList from "./components/userlist";
import Eventprops from "./components/eventprops";
import StateDemo from "./components/statedemo";
import { BrowserRouter, Route, Link, Switch } from "react-router-dom";
import About from "./components/about";
import Header from "./components/header";
import Form from "./components/form";
import FormDemo2 from "./components/formdemo2";
import FormEg from "./components/FormEg";
import ReactDOM from "react-dom";
import RefsDemo from "./components/RefsDemo";
import Customerinfo from "./components/customerinfo";
import Homes from "./components/Homes";
import LifecycleA from "./components/lifecyclesA";
import Contact from "./components/contact";
import ParentComponent from "./components/proptypes";
import Parent from "./components/parent";
import Parent1 from "./components/parent1";

class App extends Component {
  render() {
    let numbers = [11, 12, 13, 14, 15, 16];

    let user = {
      name: "Sangu",
      hobbies: ["Music", "Sports", "Drawing", "Riding"]
    };
    return (
      // <h1>Welcome to Routing Module</h1>
      // <div className="container">

      <BrowserRouter>
        <div>
          <Header />

          <div className="container">
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/about" component={About} />
              <Route exact path="/form" component={Form} />
              <Route exact path="/formdemo2" component={FormDemo2} />
              <Route exact path="/formeg" component={FormEg} />
              <Route exact path="/refsdemo" component={RefsDemo} />
              <Route exact path="/customerinfo" component={Customerinfo} />
              <Route exact path="/homes" component={Homes} />
              <Route exact path="/lifecycle" component={LifecycleA} />
              <Route exact path="/contact" component={Contact} />
              <Route exact path="/proptypes" component={ParentComponent} />
              <Route exact path="/parent" component={Parent} />
              <Route exact path="/parent1" component={Parent1} />
            </Switch>
            <Parent1>
              <h1>i am child</h1>

              <h1>i am child</h1>
            </Parent1>
          </div>
        </div>
      </BrowserRouter>

      // <div className="container">
      //   <div className="jumbotron">
      //     <h1 align="center">Welcome to Amruth..!</h1></div>
      //   <div className="row">
      //     <div className="col-xs-12">
      //       <Home />
      //     </div>
      //   </div>
      //   <div className="row">
      //     <div className="col-xs-10 col-xs-offset-1">
      //       <Welcome />
      //       <br />
      //       <p>This is another tag</p>
      //     </div>
      //   </div>
      //   {/* <FunClassDemo /> */}
      // </div>

      // <div className="container">
      //   <div className="row">
      //     <div className="col-xs-12">
      //       <Greeting name="Amruth" />
      //       <Greeting name="Raju" />
      //       <Greeting name="Manikya" />
      //       <Greetings />
      //       <NumListClassComp numbers={numbers} />
      //       <br />
      //       <UserList user={user} >Hello Friends</UserList>
      //       <br />
      //       <Eventprops age={23} />
      //       <StateDemo message="Welcome Guest" />
      //       <NumListClassComp name={user.name} age={30} user={user} />
      //       <NumListClassComp hobbies={user.hobbies} />
      //       <EventDemo1 />
      //     </div >
      //   </div >
      // </div >
    );
  }
}

export default App;

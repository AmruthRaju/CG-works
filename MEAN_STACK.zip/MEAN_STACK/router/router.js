var express = require('express');
var router = express.Router();
const item = require('../model/item');

router.get('/', (req, res) => {
    console.log('am from different router module');
    res.send('am from different router module')
});

router.post('/item', (req, res, next) => {
    const newitem = new item(
        {
            itemname: req.body.itemname,
            itemquantity: req.body.itemquantity,
            itembought: req.body.itembought
        }); // item.close



    newitem.save((err, item) => {
        if (err) {
            res.json(err);
        }
        else {
            res.json({ msg: ' inserted ' })
        }
    })
});

router.get('/items', (req, res) => {
    item.find({}, (err, item) => {
        if (err) {
            res.json(err)
        }
        else {
            res.json(item)

        }
    })
})
router.get('/item/:id', function (req, res) {
    item.findById(req.params.id,(err,data)=>{
if(err){
res.json(err)
}
else{
    res.json(data)

}
    })
 
});


router.delete('/item/:id', (req, res) => {
    item.findByIdAndRemove(req.params.id , (err, result) => {
        if (err) {
            res.json(err);
        }
        else {
            res.json(result)
        }
    })
})

router.put('/item/:id',(req,res,next)=>{
    item.findOneAndUpdate({_id:req.params.id}, {
        $set:{
            itemname: req.body.itemname,
            itemquantity: req.body.itemquantity,
            itembought: req.body.itembought
        }
    }, (err,result) => {
        if(err)
        {
            res.json(err)
        }
        else
        {
            res.json({msg:'item has been updated successfully'})
        }
    })
});

module.exports = router;

const mongoose = require('mongoose');
const itemschema = mongoose.Schema(
    {
        itemname:{
            type:String,
            requied:false,
        },
        itemquantity:{
            type:Number,
            requied:false,
        },
        itembought:{
            type:Boolean,
            requied:false,
        },
    });
    const items = module.exports = mongoose.model('items',itemschema);  
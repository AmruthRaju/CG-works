var express = require('express');

var mongoose = require('mongoose');

const cors = require('cors');

const route = require('./router/router');
// var router = express.Router();

mongoose.connect('mongodb://localhost:27017/mydb');

mongoose.connection.on('connected', () => {
    console.log('Server is started on port 27017')
})

var app = express();
app.use(express.json());
app.use(cors());
// router.get();
// router.post();
// router.delete();

app.get('/', (req, res) => {
    res.send('Hello from root path.');
});



// add an middleware to configure the routes


// add an middle ware to configure the routes
app.use('/api',route); // solves CANNOT GET / error in browser (here)

const port = 500;
app.listen(port, function () {
    console.log('Server started at port '+port);
})


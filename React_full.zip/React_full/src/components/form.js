import React from "react";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      firstname: "",
      lastname: "",
      topic: "Angular"
    };
  }
  handleSubmit = event => {
    alert(`
        Name: ${this.state.firstname} ${this.state.lastname}
       Topic: ${this.state.topic}`);
    console.log(this.state.firstname);
    console.log(this.state.lastname);
    console.log(this.state.topic);
    event.preventDefault();
  };
  handleChangeFirstName = event => {
    this.setState({
      firstname: event.target.value
    });
  };
  handleChangeLastName = event => {
    this.setState({
      lastname: event.target.value
    });
  };
  handleChangeTopic = event => {
    this.setState({
      topic: event.target.value
    });
  };

  render() {
    return (
      <div>
        <h1>Welcome to Form Page</h1>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>First Name:</label>&nbsp;
            <input type="text" value={this.state.firstname} onChange={this.handleChangeFirstName} />
          </div>
          <div>
            <label>Last Name:</label>&nbsp;
            <input type="text" value={this.state.lastname} onChange={this.handleChangeLastName} />
          </div>
          <div>
            <label>Topic:</label>&nbsp;
            <select value={this.state.topic} onChange={this.handleChangeTopic}>
              <option value="Angular">Angular</option>
              <option value="Node">Node</option>
              <option value="React">React</option>
            </select>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default Form;

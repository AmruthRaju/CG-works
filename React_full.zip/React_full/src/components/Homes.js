import React, { Component } from "react";

class Homes extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to Land Rover Page</h1>
        <img src={require("./images/801774.jpg")} width="1100px" height="700px" />
      </div>
    );
  }
}

export default Homes;

import React from "react";

class Home extends React.Component {
  render() {
    return <h1>Welcome to Home Page</h1>;
  }
}

export default Home;

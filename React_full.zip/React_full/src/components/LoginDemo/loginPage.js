import React from "react";

class LoginPage extends React.Component {
  constructor() {
    super();
    this.state = {
      user: {
        userName: "",
        passWord: ""
      }, 

      display: false,
      view: true
    }; 
  }
  UpdateState(ctrl, value) {
    const { user } = this.state; 
    user[ctrl] = value; 
    this.setState({ user });
  }

  handleSubmit(e) {
    e.preventDefault();
    alert('Logging In successfully!!');
    this.setState({ display: true });
    this.setState({ view: false });
    console.log(`${this.state.user.userName}`)
    console.log(`${this.state.user.passWord}`)

  }

  render() {
    const { user } = this.state;
    return (
      <form onSubmit={e => this.handleSubmit(e)}>
        <div className=" col-lg-4">
          <h1>Login Page</h1>
          <h2>Sign In</h2>
          <br />
          <input
            type="text"
            className="form-control"
            value={user.userName}
            placeholder="Enter your name"
            onChange={e => this.UpdateState("userName", e.currentTarget.value)}
          />
          <br />
          <input
            type="password"
            className="form-control"
            value={user.passWord}
            placeholder="Enter your password"
            onChange={e => this.UpdateState("passWord", e.currentTarget.value)}
          />
          <br />
          <button type="submit" className="btn btn-success">
            Submit
          </button>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button type="reset" className="btn btn-danger">
            Cancel
          </button>
        </div>
      </form>
    );
  }
}

export default LoginPage;

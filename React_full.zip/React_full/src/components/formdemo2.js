import React from "react";

class FormDemo2 extends React.Component {
  constructor(props) {
    super();
    this.state = {
      value: "",
      displayValue: ""
    };
  }
  handleInputChange = event => {
    console.log("evt", event.target.value);
    this.setState({
      value: event.target.value
    });
  };

  handleClick = () => {
    this.setState({
      displayValue: this.state.value.toUpperCase(),
      value: ""
    });
  };
  render() {
    return (
      <div>
        <h1>Welcome to Form Demo 2 Page</h1>

        <div>
          <h2>{this.state.displayValue}</h2>
          <label>Name:</label>&nbsp;
          <input type="text" value={this.state.value} onChange={this.handleInputChange} />
        </div>
        <button onClick={this.handleClick}>Click</button>
      </div>
    );
  }
}

export default FormDemo2;

import React, { Component } from "react";

class Image extends Component {
  // state={msg1:true}
  constructor() {
    super();
    this.state = { msg1: true };
  }

  toggle = () => {
    this.setState({
      msg1: !this.state.msg1
    });
  };

  render() {
    return (
      <div>
        <button className="btn btn-info" onClick={this.toggle}>
          Toggle Image
        </button>
        <br />
        <br />
        {this.state.msg1 ? (
          <img src={require("./images/801774.jpg")} width="800px" height="500px" />
        ) : (
          <img src={require("./images/258960.jpg")} width="800px" height="500px" />
        )}
      </div>
    );
  }
}

export default Image;

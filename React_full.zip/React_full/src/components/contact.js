import React from "react";
import AddContact from "./addcontact";
import ShowContact from "./showcontact";
import axios from "axios";

class Contact extends React.Component {
  constructor() {
    super();
    this.state = { contacts: [] };
  }

  baseURL = " http://localhost:3000/contacts/";

  componentDidMount() {
    this.getContacts();
  }

  getContacts = () => {
    axios.get(this.baseURL).then(response => {
      this.setState({ contacts: response.data });
    });
  };

  addContact = contact => {
    axios.post(this.baseURL, contact).then(response => {
      this.getContacts();
      alert("Contact added!!!");
    });
  };

  deleteContact = id => {
    alert("contact id : " + id);
    axios.delete(this.baseURL + id).then(
      res => {
        this.getContacts();
      },
      err => {
        this.setState({ errors: err });
      }
    );
  };

  

  render() {
    return (
      <div>
        <h1 className="page-header">Manage Contacts</h1>
        <AddContact addContacts={contact => this.addContact(contact)} />
        <ShowContact contacts={this.state.contacts} 
        deleteContact={this.deleteContact}/>
      </div>
    );
  }
}

export default Contact;

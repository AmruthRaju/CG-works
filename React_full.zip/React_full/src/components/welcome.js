import React, { Component } from "react";

class Welcome extends Component {
  constructor() {
    super();
    {
      this.name = "Amruth Raju";
    }
  }

  render() {
    let message = "";
    if (true) {
      message = "Hello Friends";
    }
    return (
      <div>
        <h1>Hello from Welcome component</h1>
        <h3>{2 + 2}</h3>
        <h3>{message}</h3>
        <h3>{this.name}</h3>
        <button className="btn btn-info">Click Me</button>
      </div>
    );
  }
}
export default Welcome;

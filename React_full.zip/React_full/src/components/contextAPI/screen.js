import React from "react";
import { MallContext } from "./index";

const MovieDisplay = (props) => {
  return (
    <div>
      <h1>Screen Name</h1>

      {props.movie.map(n => (
        <li>{n.movie}</li>
      ))}
      <h1>Screen Time</h1>
      {props.movie.map(n => (
        <li>{n.time}</li>
      ))}
    </div>
  );
};

class Screen extends React.Component {
  render() {
    return (
      <MallContext.Consumer>{movies => <MovieDisplay movie={movies} />}</MallContext.Consumer>
    );
  }
}

export default Screen;

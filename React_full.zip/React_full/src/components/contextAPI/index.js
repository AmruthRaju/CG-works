import React from 'react';
import Mall from './mall';
export const MallContext = React.createContext();

class ContextDemo extends React.Component{
    render(){
        const movies=[
            {movie:'Tiger',time:'9pm'},
            {movie:'Cheetah',time:'1pm'},
            {movie:'Lion',time:'5pm'}
        ]
        return(
            <MallContext.Provider value={movies}>
                <Mall/>
            </MallContext.Provider>
        )
    }
}

export default ContextDemo;
import React from 'react';
import Theatre from './theatre';

class Mall extends React.Component{
    render(){
        return(
            <div>
                <h1>Mall</h1>
                <Theatre/>
            </div>
        )
    }
}

export default Mall;
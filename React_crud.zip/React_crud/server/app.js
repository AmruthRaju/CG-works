//==============================================declarations======================
var express = require('express')

var mongoose=require('mongoose')
var app= new express()
var cors=require('cors')
const route=require('./router/router')

//================================================================ funcs()==================
app.use(express.json())
app.use(cors())
//for connection to mongodb
mongoose.connect('mongodb://localhost:27017/axios')
mongoose.connection.on('connected',function(){
    console.log("mongo db connected on port 27017")
})
app.get('/',(req,res)=>{
    res.send('hello from root path')
})
app.use('/api',route)
const port=2000
app.listen(port,function(){
    console.log('server running in 2000 port')
})
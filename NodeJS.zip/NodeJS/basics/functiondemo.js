function helloworld(name) {
    console.log('Welcome to ' + name);
}
// call the helloworld function
helloworld('Hello World');
var modobj1=require('./lib/mod1');
var modobj2=require('./lib/mod2');

console.log(modobj1);
console.log(modobj1.id);

modobj1.doget();
console.log(modobj2.id);


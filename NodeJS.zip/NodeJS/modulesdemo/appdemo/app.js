var mod1obj = require('./mod1')
mod1obj.getData();
mod1obj.getLogin();   

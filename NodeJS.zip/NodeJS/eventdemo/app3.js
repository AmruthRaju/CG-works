// import { EventEmitter } from "events";

// setTimeout(function(str1,str2){
//     console.log(str1+""+str2);
// },5000,"Hello, ","How are you?");

var timeOut = setTimeout(function(str1, str2) {

    console.log(str1 + " " + str2);
  
  }, 5000, "Hello.", "How are you?");
  
   
  
//   clearTimeout(timeOut);


//   var ee = new EventEmitter();
//   var timer;

//   ee.once("start",(startPos)=>{
//       var i = startPos;
//       console.log("Starting Timer");
//       timer = setInterval(()=>{
//           console.log(i);
//       })
//   })
var empobj = require('./mod4')
empobj.emp();
empobj.pro("amruth");
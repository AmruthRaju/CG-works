var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/mobile'
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log('Connection established ' + url);
        var db = client.db('mobile');
        var collection = db.collection('mobiledata');
        var mobone = { mobId: 100, mobilename: "Samsung", mobilecost: 70000 }
        var mobtwo = { mobId: 200, mobilename: "Iphone", mobilecost: 90000 }

        collection.update(mobone,{ $set: {mobilename: "Nokia"} }, function (err, data) {
            if (err) {
                console.log(err)
            }
            else {
                console.log(data + ' updated.')
            }
        })
    }
})

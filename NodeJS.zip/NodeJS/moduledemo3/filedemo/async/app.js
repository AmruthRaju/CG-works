const
    fsobj = require('fs');

fsobj.readFile('input.txt',
    function (err, data) {
        if (err) {
            console.log("problem in reading the file");
        }
        else {
            console.log('reading');
        }
    });
console.log('program ended');
    // // sync operation
    // var data = fsobj.readFile('input.txt');
    // console.log("synchronous reading.." + data.toString());
    // console.log('program end .')
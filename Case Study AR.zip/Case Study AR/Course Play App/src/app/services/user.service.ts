import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Course } from "../model/user";

@Injectable({
  providedIn: "root"
})
export class UserService {
  baseurl: string = "http://localhost:3000/courses";
  constructor(private http: HttpClient) {}

  // Get user
  getCourses() {
    return this.http.get<Course[]>(this.baseurl);
  }

  //Add user
  createCourse(course: Course) {
    return this.http.post<Course[]>(this.baseurl, course);
  }
}
